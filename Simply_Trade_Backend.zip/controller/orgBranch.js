const orgBranch = require("../models/orgBranch");
const bcrypt = require("bcrypt");
const userModel = require("../models/user");
const user = require("../models/user");
const { default: mongoose } = require("mongoose");

/**********************   Create Organization Branch *********/

exports.createorgbranch = async (req, res) => {
  try {
    const { userId } = req;
    const {
      organizationId,
      branchName,
      primaryAddress,
      addresslineOne,
      addresslineTwo,
      city,
      pinCode,
      district,
      state,
      country,
      mobile,
      telephone,
      email,
      password,
    } = req.body;

    const findEmail = await orgBranch.findOne({ email });
    const findPhone = await orgBranch.findOne({ mobile });

    if (findEmail) {
      return res
        .status(400)
        .json({ error: false, message: "Email already exists" });
    }
    if (findPhone) {
      return res
        .status(400)
        .json({ error: false, message: "Phone no. already exists" });
    }

    const salt = await bcrypt.genSalt(10);
    const bcryptPass = await bcrypt.hash(password, salt);

    const branchdata = await orgBranch.create({
      userId,
      organizationId,
      branchName,
      primaryAddress,
      addresslineOne,
      addresslineTwo,
      city,
      pinCode,
      district,
      state,
      country,
      mobile,
      telephone,
      email,
      password: bcryptPass,
    });

    return res.status(200).json({
      error: false,
      data: branchdata,
      message: "Branch Created Successfully",
    });
  } catch (error) {
    console.log(error);
    return res.status(400).json({ error: true, message: error.message });
  }
};

/********************** Get  Organization Branch By Organization Id *********/

exports.getbranchbyorgid = async (req, res) => {
  const { oId } = req.params;

  try {
    const getbranchbyorgid = await orgBranch
      .find({ organizationId: oId, isDelete: "0" })
      .select("-password")
      .sort({ createdAt: -1 })
      .lean()
      .exec();
    return res.status(200).json({ error: false, data: getbranchbyorgid });
  } catch (error) {
    return res.status(400).json({ error: true, message: error.message });
  }
};

/***************** Get Organization Branch By Id ********************/

exports.getorgbranchbyid = async (req, res) => {
  try {
    const { userId } = req;

    const getorgbranchbyid = await orgBranch
      .find({ _id: userId })
      .select("-password")
      .sort({ createdAt: -1 })
      .lean()
      .exec();
    return res
      .status(200)
      .json({ error: false, data: getorgbranchbyid, userId });
  } catch (error) {
    return res.status(400).json({ error: true, message: error.message });
  }
};

/*************** Get  Organization  Branch ***************/

exports.getorgbranch = async (req, res) => {
  try {
    const { userId } = req;
    const userData = await user.findById(userId);

    let finalObject = {};
    if (userData?.role == "E" && userData !== null) {
      finalObject = {
        isDelete: "0",
        userId: new mongoose.Types.ObjectId(userData.orgId),
      };
    } else if (userData?.role == "A" && userData !== null) {
      finalObject = {
        isDelete: "0",
      };
    } else {
      finalObject = {
        isDelete: "0",
        userId,
      };
    }
    const getorgbranch = await orgBranch
      .find(finalObject)
      .select("-password")
      .sort({ createdAt: -1 })
      .lean()
      .exec();
    return res.status(200).json({ error: false, data: getorgbranch });
  } catch (error) {
    return res.status(400).json({ error: true, message: error.message });
  }
};

/*************** Update Organization Branch ********************/

exports.updateorgbranchbyid = async (req, res) => {
  try {
    const { id } = req.params;
    let bcryptPass;

    if (req.body.password) {
      const salt = await bcrypt.genSalt(10);
      bcryptPass = await bcrypt.hash(req.body.password, salt);
    }

    const { password, newBranchUser, ...restOfBody } = req.body;

    let finalObject = {
      ...restOfBody,
    };

    if (bcryptPass) {
      finalObject.password = bcryptPass;
    }

    const branchData = await orgBranch.findById(id);
    if (!branchData) {
      return res.status(404).json({ error: true, message: "Branch not found" });
    }

    if (newBranchUser) {
      const newUsers = Array.isArray(newBranchUser)
        ? newBranchUser
        : [newBranchUser];

      branchData.branchUser.push(...newUsers);
      finalObject.branchUser = branchData.branchUser;

      for (const userId of newUsers) {
        const user = await userModel.findById(userId);
        if (user) {
          user.bId.push(id);
          await user.save();
        } else {
          return res
            .status(404)
            .json({ error: true, message: `User with ID ${userId} not found` });
        }
      }
    }

    const updatedBranch = await orgBranch.findByIdAndUpdate(id, finalObject, {
      new: true,
    });

    return res.status(200).json({
      error: false,
      data: updatedBranch,
      message: "Branch Updated Successfully",
    });
  } catch (error) {
    return res
      .status(400)
      .json({ error: true, message: "Something went wrong" });
  }
};

/*************** Delete Organization Branch ***************/

exports.deleteorgbranchbyid = async (req, res) => {
  try {
    const { id } = req.params;
    const dorg = await orgBranch.findByIdAndUpdate(
      id,
      { isDelete: 1 },
      { new: true }
    );
    return res.status(200).json({
      error: false,
      data: dorg,
      message: "Branch Deleted Successfully",
    });
  } catch (error) {
    return res.status(400).json({ error: true, message: error.message });
  }
};

/*************** Block  Organization Branch  ***************/

exports.blockorgbranchbyid = async (req, res) => {
  try {
    const { id } = req.params;
    const borg = await orgBranch.findByIdAndUpdate(
      id,
      { isBlock: 1 },
      { new: true }
    );
    return res.status(200).json({ error: false, data: borg });
  } catch (error) {
    return res.status(400).json({ error: true, message: error.message });
  }
};
