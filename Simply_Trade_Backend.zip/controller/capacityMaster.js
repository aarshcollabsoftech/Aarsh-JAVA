const { default: mongoose } = require("mongoose");
const capacitymaster = require("../models/capacityMaster");
const user = require("../models/user");
const organization = require("../models/organization");

exports.createCapacity = async (req, res) => {
  try {
    const { categoryId, capacity } = req.body;
    const { userId } = req;

    const added = await capacitymaster.create({ userId, categoryId, capacity });

    return res.status(200).json({
      error: false,
      message: "Capacity added successfully",
      data: added,
    });
  } catch (error) {
    return res.status(400).json({ error: true, message: error.message });
  }
};

exports.updateCapacity = async (req, res) => {
  try {
    const { id } = req.params;
    const updated = await capacitymaster.findByIdAndUpdate(id, req.body, {
      new: true,
    });

    return res.status(200).json({
      error: false,
      message: "Capacity updated successfully",
      data: updated,
    });
  } catch (error) {
    return res.status(400).json({ error: true, message: error.message });
  }
};

exports.deleteCapacity = async (req, res) => {
  try {
    const { id } = req.params;

    const deleted = await capacitymaster.findByIdAndUpdate(
      id,
      { isDelete: "1" },
      { new: true }
    );

    return res.status(200).json({
      error: false,
      data: deleted,
      message: "Capacity deleted successfully",
    });
  } catch (error) {
    return res.status(400).json({ error: true, message: error.message });
  }
};

exports.getAllCapacity = async (req, res) => {
  try {
    const { userId } = req;
    const userData = await user.findById(userId);

    let finalObject = {};
    if (userData?.role == "E" && userData !== null) {
      finalObject = {
        isDelete: "0",
        userId: new mongoose.Types.ObjectId(userData.orgId),
      };
    } else if (userData?.role == "A" && userData !== null) {
      finalObject = {
        isDelete: "0",
      };
    } else {
      finalObject = {
        isDelete: "0",
        userId,
      };
    }
    
    const capacities = await capacitymaster
      .find(finalObject)
      .sort({ createdAt: -1 })
      .lean()
      .exec();

    return res.status(200).json({
      error: false,
      message: "Capacities fetched successfully",
      data: capacities,
      userId,
    });
  } catch (error) {
    return res.status(400).json({ error: true, message: error.message });
  }
};


exports.getAllCapacityForDisplay = async (req, res) => {
  try {
    
    const capacities = await capacitymaster
      .find({isDelete:"0"})
      .sort({ createdAt: -1 })
      .lean()
      .exec();

    return res.status(200).json({
      error: false,
      message: "Capacities fetched successfully",
      data: capacities,
    });
  } catch (error) {
    return res.status(400).json({ error: true, message: error.message });
  }
};
