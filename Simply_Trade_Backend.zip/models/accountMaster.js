const mongoose = require("mongoose");

const accountMasterSchema = mongoose.Schema(
  {
    organizationId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "organization",
    },
    branchId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "orgbranch",
    },
    name: {
      type: String,
      trim: true,
    },

    balance: {
      type: Number,
      trim: true,
      default: 0,
    },
    isDelete: {
      type: String,
      enum: [1, 0],
      default: 0,
      trim: true,
    },
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "user",
    },
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model("accountmaster", accountMasterSchema);
