const mongoose = require("mongoose");

const userSchema = mongoose.Schema(
  {
    bId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "orgBranch",
      
    },
    name: {
      type: String,
      trim: true,
    },
    email: {
      type: String,
      required: [true, "Please enter your email"],
      unique: true,
      trim: true,
    },
    phone: {
      type: String,
      required: [true, "Please enter your Phone No."],
      unique: true,
    },
    amount: {
      type: Number,
      trim: true,
    },
    isDelete: {
      type: String,
      enum: [1, 0],
      default: 0,
      trim: true,
    },
    isVerified: {
      type: String,
      enum: [1, 0],
      default: 0,
      trim: true,
    },
    role: {
      type: String,
      enum: ["A", "E"],
      default: "E",
      trim: true,
    },
    password: {
      type: String,
      required: [true, "Please enter your password"],
    },
    orgId: {
      type: String,
      trim: true,
    },
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "user",
    },
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model("user", userSchema);
