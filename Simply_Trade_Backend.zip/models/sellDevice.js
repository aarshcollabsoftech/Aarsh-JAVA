const mongoose = require("mongoose");
const sellDevice = mongoose.Schema(
  {
    bId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "user",
    },
    orgId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "organization",
    },
    deviceId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "devicemaster",
    },
    customerName: {
      type: String,
      trim: true,
    },
    customerPhone: {
      type: String,
      trim: true,
    },
    poId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "customermaster",
    },
    sellingPrice: {
      type: String,
      trim: true,
    },
    paymentDetails: {
      type: Array,
      default: Array,
    },
    attachments: {
      type: Array,
      default: Array,
    },
    isSold: {
      type: String,
      enum: [1, 0],
      default: 1,
    },
    pbId: {
      // phone Buyer ID
      type: mongoose.Schema.Types.ObjectId,
      ref: "customermaster",
    },
    isDelete: {
      type: String,
      enum: [1, 0],
      default: 0,
    },
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "user",
    },
    deviceData: {
      type: Object,
    },
  },
  {
    timestamps: true,
  }
);
module.exports = mongoose.model("sellDevice", sellDevice);
