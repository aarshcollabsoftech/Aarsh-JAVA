const Device = require("../models/deviceMaster");
const CustomerMaster = require("../models/customerMaster");
const accountMaster = require("../models/accountMaster");
const TransactionHistory = require("../models/transactionHistory");
const moment = require("moment");
const user = require("../models/user");
const { default: mongoose } = require("mongoose");
const CustomerBalance = require("../models/cutomerBalanceHistory");

exports.addDevice = async (req, res) => {
  try {
    const { bId, orgId, cPhone, cName, newDevices, paymentDetails } = req.body;
    const { userId } = req;

    const checkCust = await CustomerMaster.findOne({ phone: cPhone });
    let addedCust;
    let totalAmount = 0;
    if (!checkCust) {
      addedCust = await CustomerMaster.create({
        name: cName,
        phone: cPhone,
        orgId: orgId,
        branchId: bId,
        userId: userId,
      });
    } else {
      addedCust = checkCust;
    }

    const gId = Math.floor(Math.random() * 90000) + 10000;

    let addDeviceList = [];

    for (const element of paymentDetails) {
      const { paymentAccount, paymentAmount } = element;

      const account = await accountMaster.findOne({ _id: paymentAccount });
      if (!account) {
        return res.status(400).json({
          error: true,
          message: `Payment account ${paymentAccount} does not exist.`,
        });
      }
      const formattedDate = moment().format("DD/MM/YYYY HH:mm:ss");

      account.balance -= Number(paymentAmount);
      await account.save();
      await TransactionHistory.create({
        account: paymentAccount,
        amount: paymentAmount,
        transactionType: "D",
        customerId: addedCust._id,
        transactionDate: formattedDate,
        description: `Payment for device.`,
      });
      await CustomerBalance.create({
        customerId: addedCust._id,
        account: paymentAccount,
        amount: paymentAmount,
        transactionType: "C",
        transactionDate: formattedDate,
        description: `Payment recieved for device.`,
      });
    }

    for (const data of newDevices) {
      const {
        categoryId,
        mmId,
        deviceNameId,
        cmId,
        capId,

        imeiNumbersWithAmount,
        attachments,
      } = data;

      for (const imeiData of imeiNumbersWithAmount) {
        const { imeiNumber, amount } = imeiData;

        const existingDevice = await Device.findOne({ imeiNumber });
        if (existingDevice) {
          return res.status(400).json({
            error: true,
            message: `IMEI number ${imeiNumber} already exists in the database.`,
          });
        }

        totalAmount +=Number( amount);

        const addDevice = {
          userId,
          gId,
          orgId,
          bId,
          poId: addedCust._id,
          categoryId,
          mmId,
          deviceNameId,
          cmId,
          capId,
          imeiNumber,
          amount,
          attachments,
          paymentDetails
        };
        addDeviceList.push(addDevice);
      }
    }

    const addDevices = await Device.insertMany(addDeviceList);
    addedCust.amount = (addedCust.amount || 0) + Number(totalAmount);
    await addedCust.save();
    return res.status(200).json({
      error: false,
      data: addDevices,
      message: "Device Bought Successfully",
    });
  } catch (error) {
    console.log(error);
    return res.status(400).json({ error: true, message: error.message });
  }
};


exports.getDevices = async (req, res) => {
  try {
    const {userId} = req;
    const userData = await user.findById(userId);

    let finalObject = {};
    if (userData?.role == "E" && userData !== null) {
      finalObject = {
        isDelete: "0",
        isSold: "0",
        userId: new mongoose.Types.ObjectId(userData.orgId),
      };
    } else if (userData?.role == "A" && userData !== null) {
      finalObject = {
        isDelete: "0",
        isSold: "0"
      };
    } else {
      finalObject = {
        isDelete: "0",
        isSold: "0",
        userId,
      };
    }
    const soldDevices = await Device.find({ isDelete: "0", isSold: "0" })
      .sort({ createdAt: -1 })
      .lean()
      .exec();

    return res.status(200).json({
      error: false,
      message: "Device fetched successfully",
      data: soldDevices,
    });
  } catch (error) {
    return res.status(400).json({ error });
  }
};

exports.deleteDevice = async (req, res) => {
  try {
    const { id } = req.params;
    const deleted = await Device.findByIdAndUpdate(
      id,
      { isDelete: "1" },
      { new: true }
    );

    return res.status(200).json({
      error: false,
      data: deleted,
      message: "Device deleted successfully",
    });
  } catch (error) {
    return res.status(400).json({ error });
  }
};

exports.updateDeivce = async (req, res) => {
  try {
    const { id } = req.params;

    const updated = await Device.findByIdAndUpdate(id, req.body, { new: true });

    return res.status(200).json({
      error: false,
      message: "Device updated successfully",
      data: updated,
    });
  } catch (error) {
    return res.status(400).json({ error });
  }
};

exports.searchBygId = async (req, res) => {
  try {
    const { gId } = req.params;
    const GroupData = await Device.find({ gId: gId });
    return res.status(200).json({
      error: false,
      data: GroupData,
      message: "Group Data Fetched successfully",
    });
  } catch (error) {
    return res.status(400).json({ error: true, message: error.message });
  }
};

exports.addBulkDevices = async (req, res) => {
  try {
    const { bId, orgId, cPhone, cName, newDevices, paymentDetails } = req.body;
    const { userId } = req;

    const checkCust = await CustomerMaster.findOne({ phone: cPhone });
    let addedCust;
    let totalAmount = 0;
    if (!checkCust) {
      addedCust = await CustomerMaster.create({
        name: cName,
        phone: cPhone,
        orgId: orgId,
        branchId: bId,
        userId: userId,
      });
    } else {
      addedCust = checkCust;
    }

    const gId = Math.floor(Math.random() * 90000) + 10000;

    let addDeviceList = [];

    for (const element of paymentDetails) {
      const { paymentAccount, paymentAmount } = element;

      const account = await accountMaster.findOne({ _id: paymentAccount });
      if (!account) {
        return res.status(400).json({
          error: true,
          message: `Payment account ${paymentAccount} does not exist.`,
        });
      }
      const formattedDate = moment().format("DD/MM/YYYY HH:mm:ss");

      account.balance -= Number(paymentAmount);
      await account.save();
      await TransactionHistory.create({
        account: paymentAccount,
        amount: paymentAmount,
        transactionType: "D",
        customerId: addedCust._id,
        transactionDate: formattedDate,
        description: `Payment for device.`,
      });
    }

    for (const data of newDevices) {
      const {
        categoryId,
        mmId,
        deviceNameId,
        cmId,
        capId,
        imeiNumbers,
        attachments,
        unitPrice
      } = data;

      for (const imeiNumber of imeiNumbers) {
        const existingDevice = await Device.findOne({ imeiNumber });
        if (existingDevice) {
          return res.status(400).json({
            error: true,
            message: `IMEI number ${imeiNumber} already exists in the database.`,
          });
        }

        totalAmount += Number(unitPrice);

        const addDevice = {
          userId,
          gId,
          orgId,
          bId,
          poId: addedCust._id,
          categoryId,
          mmId,
          deviceNameId,
          cmId,
          capId,
          imeiNumber,
          amount: unitPrice,
          attachments,
          paymentDetails
        };
        addDeviceList.push(addDevice);
      }
    }

    const addDevices = await Device.insertMany(addDeviceList);
    addedCust.amount = (addedCust.amount || 0) + totalAmount;
    await addedCust.save();
    return res.status(200).json({
      error: false,
      data: addDevices,
      message: "Device Bought Successfully",
    });
  } catch (error) {
    console.log(error);
    return res.status(400).json({ error: true, message: error.message });
  }
};





// get Devices for display panel 


exports.getDevicesForDisplayPanel = async (req, res) => {
  try {
    const Devices = await Device.find({ isDelete: "0", isSold: "0" })
      .sort({ createdAt: -1 })
      .lean()
      .exec();

    return res.status(200).json({
      error: false,
      message: "Device fetched successfully",
      data: Devices,  
    });
  } catch (error) {
    return res.status(400).json({ error });
  }
};