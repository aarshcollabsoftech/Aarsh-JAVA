const JWT = require("jsonwebtoken");
const bcrypt = require("bcrypt");

exports.authMiddleware = async (req, res, next) => {
  try {
    const token = req.headers["authorization"]?.split(" ")[1];

    JWT.verify(token, process.env.JWT_SECRET_KEY, (err, decode) => {
      if (err) {
        return res.status(401).send({
          success: false,
          message: "Auth Failed",
        });
      } else {
        req.userId = decode.userId;
        next();
      }
    });
  } catch (error) {
    console.log(error, "error in auth middleware");
    res.status(401).send({
      success: false,
      message: "Auth Failed",
      error,
    });
  }
};

exports.apiMiddleware = async (req, res, next) => {
  try {
    let { appkey } = req.headers;
    const bcryptCompareAuth = await bcrypt.compare(
      process.env.API_AUTH_DATA,
      appkey
    );

    if (!bcryptCompareAuth) {
      throw new Error("Authorization Failed ");
    } else {
      next();
    }
  } catch (error) {
    res.status(401).send({
      success: false,
      message: "Auth Failed",
      error,
    });
  }
};
