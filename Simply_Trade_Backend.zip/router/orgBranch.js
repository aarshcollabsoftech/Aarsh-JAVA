const express = require("express");
const {
  createorgbranch,
  getbranchbyorgid,
  getorgbranch,
  getorgbranchbyid,
  updateorgbranchbyid,
  deleteorgbranchbyid,
  blockorgbranchbyid,
} = require("../controller/orgBranch");
const { authMiddleware } = require("../middleware/middleware");
const router = express.Router();

router.post("/createorgbranch", authMiddleware, createorgbranch);
router.get("/getorgbranch", authMiddleware, getorgbranch);

router.get("/getbranchbyorgid/:oId", authMiddleware, getbranchbyorgid);

router.get("/getorgbranchbyid/:id", authMiddleware, getorgbranchbyid);
router.put("/updateorgbranchbyid/:id", authMiddleware, updateorgbranchbyid);
router.put("/deleteorgbranchbyid/:id", authMiddleware, deleteorgbranchbyid);
router.put("/blockorgbranchbyid/:id", authMiddleware, blockorgbranchbyid);

module.exports = router;
