const mongoose = require("mongoose");
const deviceMaster = mongoose.Schema(
  {
    gId: {
      type: String,
    },
    categoryId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "categoryMaster",
    },
    bId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "user",
    },
    orgId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "organization",
    },
    poId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "customermaster",
    },

    mmId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "modelmaster",
    },
    cmId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "colormaster",
    },
    capId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "capacityMaster",
    },
    deviceNameId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "deviceNameMaster",
    },
    imeiNumber: {
      type: String,
      required: true,
    },
    totalAmount: {
      type: String,
      trim: true,
    },
    amount: {
      type: String,
      trim: true,
    },
    paymentDetails: {
      type: Array,
      default: Array,
    },
    attachments: {
      type: Array,
      default: Array,
    },
    isSold: {
      type: String,
      enum: [1, 0],
      default: 0,
    },
    sellingPrice: {
      type: String,
      trim: true,
    },
    soldTo: {
      type: String,
      trim: true,
    },
    status: {
      type: String,
      enum: ["B", "S", "E"],
      default: "B",
    },
    isDelete: {
      type: String,
      enum: [1, 0],
      default: 0,
    },
    pbId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "customermaster",
    },
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "user",
    },
    orgId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "organization",
    },
    
  },
  {
    timestamps: true,
  }
);
module.exports = mongoose.model("devicemaster", deviceMaster);
