const express = require("express");
const {
  createsellDevices,
  getsoldDevices,
} = require("../controller/sellDevice");
const { authMiddleware } = require("../middleware/middleware");
const router = express.Router();

router.post("/createselldevice", authMiddleware, createsellDevices);
router.get("/getsolddevices", authMiddleware, getsoldDevices);

module.exports = router;
