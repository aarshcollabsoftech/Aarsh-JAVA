const express = require("express");
const {
  createcategory,
  updatecategory,
  deletecategory,
  getAllcategory,
  getAllcategoryForDisplay,
} = require("../controller/categoryMaster");
const { authMiddleware } = require("../middleware/middleware");

const router = express.Router();

router.post("/createcategory", authMiddleware, createcategory);

router.put("/updatecategory/:id", authMiddleware, updatecategory);
router.put("/deletecategory/:id", authMiddleware, deletecategory);
router.get("/getcategory", authMiddleware, getAllcategory);
router.get("/getallcategoryfordisplay", getAllcategoryForDisplay);

module.exports = router;
