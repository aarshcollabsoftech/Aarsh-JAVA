const mongoose = require("mongoose");

const querySchema = mongoose.Schema(
  {
    deviceId: {
       type: String
    },
    orgId: {
        type: String
    },
    branchId: {
        type: String
    },

    name:{
        type:String,
        trim:true
    },
    email:{
        type:String,
        unique:true
    },
    phone:{
        type:Number,
        trim:true
    },
    city:{
        type:String,
        trim:true
    },
    isDelete: {
      type: String,
      enum: [1, 0],
      default: 0,
      trim: true,
    },
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "user",
    },
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model("queries", querySchema);
