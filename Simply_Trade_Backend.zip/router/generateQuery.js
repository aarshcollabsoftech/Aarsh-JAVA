const express = require("express");
const { generateQuery, getQueries } = require("../controller/generateQuery");

const { authMiddleware } = require("../middleware/middleware");

const router = express.Router();

router.post("/generateQuery",generateQuery); 
router.get("/getqueries",authMiddleware,getQueries); 

module.exports = router;
