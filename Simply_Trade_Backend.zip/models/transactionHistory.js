const mongoose = require("mongoose");

const TransactionHistorySchema = new mongoose.Schema({
  account: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "accountmaster",
    required: true,
  },
  amount: {
    type: Number,
    required: true,
  },
  customerId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "customermaster",
    required: true,
  },
  transactionDate: {
    type: String,
    default: Date.now,
  },
  transactionType: {
    type: String,
    enum: ["C", "D"],
    required: true,
  },
  description: {
    type: String,
    required: true,
  },
});

const TransactionHistory = mongoose.model(
  "TransactionHistory",
  TransactionHistorySchema
);

module.exports = TransactionHistory;
