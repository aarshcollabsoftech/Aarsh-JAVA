const { default: mongoose } = require("mongoose");
const Device = require("../models/deviceMaster");
const generateQuery = require("../models/generateQuery");
const user = require("../models/user");

exports.generateQuery = async (req, res) => {
  try {
    const { deviceId, name, email, phone, city } = req.body;
    const deviceDetails = await Device.findById(deviceId);
    const query = await generateQuery.create({
      orgId: deviceDetails.orgId,
      branchId: deviceDetails.bId,
      deviceId: deviceId,
      name: name,
      email: email,
      phone: phone,
      city: city,
    });

    return res.status(200).json({error:false,data:query,message:"Interest Registered .Our Representative will get in touch with you ASAP."})
  } catch (error) {
    return res.status(400).json({ error: true, message: error.message });
  }
};





exports.getQueries = async (req, res) => {
    try {
      const { userId } = req;
      const userData = await user.findById(userId);
      console.log(userData)
      let finalObject = {};
      if (userData?.role == "E" && userData !== null) {
        finalObject = {
          isDelete: "0",
          branchId: userData.bId,
        };
      } else if (userData?.role == "A" && userData !== null) {
        finalObject = {
          isDelete: "0",
        };
      } else {
        finalObject = {
          isDelete: "0",
          orgId:userId,
        };
      }
      const Queries = await generateQuery
        .find(finalObject)
        .sort({ createdAt: -1 })
        .lean()
        .exec();
      return res.status(200).json({ error: false, data: Queries });
    } catch (error) {
      return res.status(400).json({ error: true, message: error.message });
    }
  };