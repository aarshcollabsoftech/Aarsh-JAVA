const User = require("../models/user");
const OrgSchema = require("../models/organization");
const OrgBranchSchema = require("../models/orgBranch");
const JWT = require("jsonwebtoken");
const user = require("../models/user");
const { default: mongoose } = require("mongoose");

exports.getBranchUsers = async (req, res) => {
  try {
    const { bId } = req.params;
    const { userId } = req;

    const users = await User.find({ bId, isDelete: 0, userId })
      .select("-password")
      .sort({ createdAt: -1 })
      .lean()
      .exec();

    return res.status(200).json({
      error: false,
      data: users,
    });
  } catch (error) {
    return res.status(400).json({ error: true, message: error.message });
  }
};

exports.deleteUserById = async (req, res) => {
  try {
    const { id } = req.params;

    const deleteUser = await User.findByIdAndUpdate(
      id,
      { isDelete: 1 },
      {
        new: true,
      }
    )
      .lean()
      .exec();

    return res.status(200).json({
      error: false,
      data: deleteUser,
      message: "User Deleted Successfully",
    });
  } catch (error) {
    return res.status(400).json({ error: true, message: error.message });
  }
};

exports.updateUserById = async (req, res) => {
  try {
    const { id } = req.params;

    const updateuser = await User.findByIdAndUpdate(id, req.body, {
      new: true,
    })
      .lean()
      .exec();

    return res.status(200).json({
      error: false,
      data: updateuser,
      message: "User Updated Successfully",
    });
  } catch (error) {
    return res.status(400).json({ error: true, message: error.message });
  }
};

exports.getUserByToken = async (req, res) => {
  try {
    const { token } = req.body;

    var decoded = JWT.verify(token, process.env.JWT_SECRET_KEY);

    const { userId } = decoded;

    let user;
    let org;
    let orgBranch;
    user = await User.findById(userId).select("-password").lean().exec();

    if (!user) {
      org = await OrgSchema.findById(userId).select("-password").lean().exec();
    }

    if (!org) {
      orgBranch = await OrgBranchSchema.findById(userId)
        .select("-password")
        .lean()
        .exec();
    }

    let userData = user
      ? user
      : org
      ? { ...org, role: "Org" }
      : { ...orgBranch, role: "OrgBranch" };

    return res.status(200).json({ error: false, data: userData });
  } catch (error) {
    return res.status(400).json({ error: true, message: error.message });
  }
};

exports.getUsers = async (req, res) => {
  try {
    const { userId } = req;
    const userData = await user.findById(userId);

    let finalObject = {};
    if (userData?.role == "E" && userData !== null) {
      finalObject = {
        isDelete: "0",
        userId: new mongoose.Types.ObjectId(userData.orgId),
      };
    } else if (userData?.role == "A" && userData !== null) {
      finalObject = {
        isDelete: "0",
      };
    } else {
      finalObject = {
        isDelete: "0",
        userId,
      };
    }
    const users = await User.find(finalObject)
      .select("-password")
      .sort({ createdAt: -1 })
      .lean()
      .exec();

    return res.status(200).json({
      error: false,
      data: users,
    });
  } catch (error) {
    return res.status(400).json({ error: true, message: error.message });
  }
};
