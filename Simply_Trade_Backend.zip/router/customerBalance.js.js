const express = require("express");

const { authMiddleware } = require("../middleware/middleware");
const { getCustomerBalance } = require("../controller/customerBalance.js");
const router = express.Router();

router.get("/getcustomerbalance", authMiddleware, getCustomerBalance);

module.exports = router;
