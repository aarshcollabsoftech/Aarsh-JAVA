const express = require("express");
const {
  addDevice,
  getDevices,
  deleteDevice,
  updateDeivce,
  searchBygId,
  addBulkDevices,
  getDevicesForDisplayPanel,
} = require("../controller/deviceMaster");
const { authMiddleware } = require("../middleware/middleware");

const router = express.Router();

router.post("/adddevice", authMiddleware, addDevice);
router.put("/deletedevice/:id", authMiddleware, deleteDevice);
router.put("/updatedevice/:id", authMiddleware, updateDeivce);
router.get("/getdevice", authMiddleware, getDevices);
router.get("/searchbygid/:gId", authMiddleware, searchBygId);
router.post("/addbulkdevice", authMiddleware, addBulkDevices);
router.get("/getDevicesForDisplayPanel", getDevicesForDisplayPanel);

module.exports = router;
