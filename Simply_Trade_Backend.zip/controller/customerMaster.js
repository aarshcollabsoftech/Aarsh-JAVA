const { default: mongoose } = require("mongoose");
const CustomerMaster = require("../models/customerMaster");
const user = require("../models/user");

/**************** Create Customer ******************/
exports.createCustomer = async (req, res) => {
  try {
    const { name, phone, branchId, orgId, amount } = req.body;
    const { userId } = req;

    const added = await CustomerMaster.create({
      userId,
      name,
      phone,
      branchId,
      orgId,
      amount,
    });

    return res.status(200).json({
      error: false,
      message: "Customer added successfully",
      data: added,
    });
  } catch (error) {
    return res.status(400).json({ error: true, message: error.message });
  }
};

/**************** Update Customer ******************/
exports.updateCustomer = async (req, res) => {
  try {
    const { id } = req.params;
    const updated = await CustomerMaster.findByIdAndUpdate(id, req.body, {
      new: true,
    });

    return res.status(200).json({
      error: false,
      message: "Customer updated successfully",
      data: updated,
    });
  } catch (error) {
    return res.status(400).json({ error: true, message: error.message });
  }
};

/**************** Delete Customer ******************/
exports.deleteCustomer = async (req, res) => {
  try {
    const { id } = req.params;

    const deleted = await CustomerMaster.findByIdAndUpdate(
      id,
      { isDelete: "1" },
      { new: true }
    );

    return res.status(200).json({
      error: false,
      data: deleted,
      message: "Customer deleted successfully",
    });
  } catch (error) {
    return res.status(400).json({ error: true, message: error.message });
  }
};

/**************** Get All Customers ******************/
exports.getAllCustomers = async (req, res) => {
  try {
    const { userId } = req;
    const userData = await user.findById(userId);

    let finalObject = {};
    if (userData?.role == "E" && userData !== null) {
      finalObject = {
        isDelete: "0",
        userId: new mongoose.Types.ObjectId(userData.orgId),
      };
    } else if (userData?.role == "A" && userData !== null) {
      finalObject = {
        isDelete: "0",
      };
    } else {
      finalObject = {
        isDelete: "0",
        orgId:userId,
      };
    }
    const customers = await CustomerMaster.find(finalObject)
      .sort({ createdAt: -1 })
      .lean()
      .exec();

    return res.status(200).json({
      error: false,
      message: "Customers fetched successfully",
      data: customers,
      userId,
    });
  } catch (error) {
    return res.status(400).json({ error: true, message: error.message });
  }
};
