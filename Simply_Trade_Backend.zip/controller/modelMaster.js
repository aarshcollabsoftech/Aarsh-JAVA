const { default: mongoose } = require("mongoose");
const Modelmaster = require("../models/modelMaster");
const user = require("../models/user");

/**************** Create Model ******************/
exports.createModel = async (req, res) => {
  try {
    const { userId } = req;
    const { categoryId, modelName } = req.body;
    const added = await Modelmaster.create({ userId, categoryId, modelName });

    return res.status(200).json({
      error: false,
      message: "Model added successfully",
      data: added,
    });
  } catch (error) {
    return res.status(400).json({ error: true, message: error.message });
  }
};

/**************** Update  Model ******************/
exports.updateModel = async (req, res) => {
  try {
    const { id } = req.params;
    const updated = await Modelmaster.findByIdAndUpdate(id, req.body, {
      new: true,
    });

    return res.status(200).json({
      error: false,
      message: "Model updated successfully",
      data: updated,
    });
  } catch (error) {
    return res.status(400).json({ error: true, message: error.message });
  }
};
/**************** Delete  Model ******************/

exports.deleteModel = async (req, res) => {
  try {
    const { id } = req.params;

    const deleted = await Modelmaster.findByIdAndUpdate(
      id,
      { isDelete: "1" },
      { new: true }
    );

    return res.status(200).json({
      error: false,
      data: deleted,
      message: "Model deleted successfully",
    });
  } catch (error) {
    return res.status(400).json({ error: true, message: error.message });
  }
};

/**************** Get  Model ******************/
exports.getAllModel = async (req, res) => {
  try {
    const { userId } = req;
    const userData = await user.findById(userId);

    let finalObject = {};
    if (userData?.role == "E" && userData !== null) {
      finalObject = {
        isDelete: "0",
        userId: new mongoose.Types.ObjectId(userData.orgId),
      };
    } else if (userData?.role == "A" && userData !== null) {
      finalObject = {
        isDelete: "0",
      };
    } else {
      finalObject = {
        isDelete: "0",
        userId,
      };
    }
    const models = await Modelmaster.find(finalObject)
      .sort({ createdAt: -1 })
      .lean()
      .exec();

    return res.status(200).json({
      error: false,
      message: "Model fetched successfully",
      data: models,
    });
  } catch (error) {
    return res.status(400).json({ error: true, message: error.message });
  }
};


exports.getAllModelForDisplay = async (req, res) => {
  try {
   
    const models = await Modelmaster.find({isDelete:"0"})
      .sort({ createdAt: -1 })
      .lean()
      .exec();

    return res.status(200).json({
      error: false,
      message: "Model fetched successfully",
      data: models,
    });
  } catch (error) {
    return res.status(400).json({ error: true, message: error.message });
  }
};
