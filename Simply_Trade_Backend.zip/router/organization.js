const express = require("express");
const {
  createorg,
  getorg,
  getorgbyadminid,
  getorgbyid,
  updateorgbyid,
  deleteorgbyid,
  blockorgbyid,
} = require("../controller/organization");
const { authMiddleware } = require("../middleware/middleware");

const router = express.Router();

router.post("/createorg", authMiddleware, createorg);
router.get("/getorg", authMiddleware, getorg);

router.get("/getorgbyadminid/:aId", authMiddleware, getorgbyadminid);

router.get("/getorgbyid/:id", authMiddleware, getorgbyid);
router.put("/updateorgbyid/:id", authMiddleware, updateorgbyid);
router.put("/deleteorgbyid/:id", authMiddleware, deleteorgbyid);
router.put("/blockorgbyid/:id", authMiddleware, blockorgbyid);

module.exports = router;
