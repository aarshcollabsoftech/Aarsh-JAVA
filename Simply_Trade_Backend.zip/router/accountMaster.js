const express = require("express");
const {
  createaccount,
  updateaccount,
  deleteaccount,
  getAllaccount,
} = require("../controller/accountMaster");
const { authMiddleware } = require("../middleware/middleware");

const router = express.Router();

router.post("/createaccount", authMiddleware, createaccount);

router.put("/updateaccount/:id", authMiddleware, updateaccount);
router.put("/deleteaccount/:id", authMiddleware, deleteaccount);
router.get("/getaccounts", authMiddleware, getAllaccount);

module.exports = router;
