const express = require("express");
const {
  createColor,
  updateColor,
  deleteColor,
  getAllColor,
  getAllColorForDisplay,
} = require("../controller/colorMaster");
const { authMiddleware } = require("../middleware/middleware");

const router = express.Router();

router.post("/createcolor", authMiddleware, createColor);

router.put("/updatecolor/:id", authMiddleware, updateColor);
router.put("/deletecolor/:id", authMiddleware, deleteColor);
router.get("/getcolors", authMiddleware, getAllColor);
router.get("/getallcolorfordisplay" , getAllColorForDisplay);

module.exports = router;
