const { default: mongoose } = require("mongoose");
const ColorMaster = require("../models/colorMaster");
const user = require("../models/user");

exports.createColor = async (req, res) => {
  try {
    const { colorName } = req.body;
    const { userId } = req;
    const color = colorName.charAt(0).toUpperCase() + colorName.slice(1);
    const added = await ColorMaster.create({ userId, colorName: color });

    return res.status(200).json({
      error: false,
      message: "Color added successfully",
      data: added,
    });
  } catch (error) {
    return res.status(400).json({ error: true, message: error.message });
  }
};

exports.updateColor = async (req, res) => {
  try {
    const { id } = req.params;
    const updated = await ColorMaster.findByIdAndUpdate(id, req.body, {
      new: true,
    });

    return res.status(200).json({
      error: false,
      message: "Color updated successfully",
      data: updated,
    });
  } catch (error) {
    return res.status(400).json({ error: true, message: error.message });
  }
};

exports.deleteColor = async (req, res) => {
  try {
    const { id } = req.params;

    const deleted = await ColorMaster.findByIdAndUpdate(
      id,
      { isDelete: "1" },
      { new: true }
    );

    return res.status(200).json({
      error: false,
      data: deleted,
      message: "Color deleted successfully",
    });
  } catch (error) {
    return res.status(400).json({ error: true, message: error.message });
  }
};

exports.getAllColor = async (req, res) => {
  try {
    const { userId } = req;
    const userData = await user.findById(userId);

    let finalObject = {};
    if (userData?.role == "E" && userData !== null) {
      finalObject = {
        isDelete: "0",
        userId: new mongoose.Types.ObjectId(userData.orgId),
      };
    } else if (userData?.role == "A" && userData !== null) {
      finalObject = {
        isDelete: "0",
      };
    } else {
      finalObject = {
        isDelete: "0",
        userId,
      };
    }
    const colors = await ColorMaster.find(finalObject)
      .sort({ createdAt: -1 })
      .lean()
      .exec();

    return res.status(200).json({
      error: false,
      message: "Color fetched successfully",
      data: colors,
    });
  } catch (error) {
    return res.status(400).json({ error: true, message: error.message });
  }
};


exports.getAllColorForDisplay = async (req, res) => {
  try {
  
    const colors = await ColorMaster.find({isDelete:"0"})
      .sort({ createdAt: -1 })
      .lean()
      .exec();

    return res.status(200).json({
      error: false,
      message: "Color fetched successfully",
      data: colors,
    });
  } catch (error) {
    return res.status(400).json({ error: true, message: error.message });
  }
};
