const { default: mongoose } = require("mongoose");
const transaction = require("../models/transactionHistory");
const user = require("../models/user");
exports.getTransactionHistory = async (req, res) => {
  try {
    const { userId } = req;
    const userData = await user.findById(userId);

    let finalObject = {};
    if (userData?.role == "E" && userData !== null) {
      finalObject = {
        userId: new mongoose.Types.ObjectId(userData.orgId),
      };
    } else if (userData?.role == "A" && userData !== null) {
      finalObject = {
      };
    } else {
      finalObject = {
        userId,
      };
    }
    const history = await transaction
      .find(finalObject)
      .sort({ createdAt: -1 })
      .lean()
      .exec();

    return res.status(200).json({
      error: false,
      message: "History fetched successfully",
      data: history,
      userId,
    });
  } catch (error) {
    return res.status(400).json({ error: true, message: error.message });
  }
};
