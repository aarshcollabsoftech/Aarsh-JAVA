const express = require("express");
const {
  createModel,
  updateModel,
  deleteModel,
  getAllModel,
  getAllModelForDisplay,
} = require("../controller/modelMaster");
const { authMiddleware } = require("../middleware/middleware");

const router = express.Router();

router.post("/createmodel", authMiddleware, createModel);

router.put("/updatemodel/:id", authMiddleware, updateModel);
router.put("/deletemodel/:id", authMiddleware, deleteModel);
router.get("/getmodels", authMiddleware, getAllModel);
router.get("/getallmodelfordisplay",getAllModelForDisplay);

module.exports = router;
