const express = require("express");
const {
  createCustomer,
  updateCustomer,
  getAllCustomers,
  deleteCustomer,
} = require("../controller/customerMaster");
const { authMiddleware } = require("../middleware/middleware");

const router = express.Router();

router.post("/createcustomer", authMiddleware, createCustomer);

router.put("/updatecustomer/:id", authMiddleware, updateCustomer);
router.put("/deletecustomer/:id", authMiddleware, deleteCustomer);
router.get("/getcustomers", authMiddleware, getAllCustomers);

module.exports = router;
