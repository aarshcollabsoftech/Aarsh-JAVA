const express = require("express");
const {
  login,
  addUser,
  forgotPassword,
  resetPassword,
  signup,
  editUser,
  verifyUserbytoken,
  deleteUser,
} = require("../controller/auth");
const { authMiddleware } = require("../middleware/middleware");

const router = express.Router();

router.post("/login", login);
router.post("/adduser", authMiddleware, addUser);
router.post("/forgotpassword", forgotPassword);
router.post("/resetpassword", resetPassword);
router.post("/verifyuser/:token", verifyUserbytoken);
router.post("/signup", signup);
router.put("/edituser/:id", authMiddleware, editUser);
router.put("/deleteuser/:id", authMiddleware, deleteUser);

module.exports = router;
