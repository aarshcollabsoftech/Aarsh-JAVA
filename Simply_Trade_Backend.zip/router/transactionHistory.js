const express = require("express");

const { authMiddleware } = require("../middleware/middleware");
const { getTransactionHistory } = require("../controller/transactionHistory");
const router = express.Router();

router.get("/gettransactionhistory", authMiddleware, getTransactionHistory);

module.exports = router;
