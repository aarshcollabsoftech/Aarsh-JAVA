const Device = require("../models/deviceMaster");
const CustomerMaster = require("../models/customerMaster");
const sellDevice = require("../models/sellDevice");
const TransactionHistory = require("../models/transactionHistory");
const accountMaster = require("../models/accountMaster");
const moment = require("moment");
const user = require("../models/user");
const { default: mongoose } = require("mongoose");
const CustomerBalance = require("../models/cutomerBalanceHistory");

exports.getsoldDevices = async (req, res) => {
  try {
    const { userId } = req;
    const userData = await user.findById(userId);

    let finalObject = {};
    if (userData?.role == "E" && userData !== null) {
      finalObject = {
        isDelete: "0",
        isSold: "1",
        userId: new mongoose.Types.ObjectId(userData.orgId),
      };
    } else if (userData?.role == "A" && userData !== null) {
      finalObject = {
        isDelete: "0",
        isSold: "1"
      };
    } else {
      finalObject = {
        isDelete: "0",
        userId,
      };
    }

    const soldData = await sellDevice.find({ isSold: "1" });
    return res.status(200).json({
      error: false,
      data: soldData,
      message: "Sold  devices list",
    });
  } catch (error) {
    return res.status(400).json({ error: true, message: error.message });
  }
};

exports.createsellDevices = async (req, res) => {
  try {
    const { userId } = req;
    const { orgId, bId, cName, cPhone, sellRequests, paymentDetails } = req.body;

    let buyer = await CustomerMaster.findOne({ phone: cPhone });
    if (!buyer) {
      buyer = await CustomerMaster.create({
        userId,
        name: cName,
        phone: cPhone,
        orgId:orgId,
        branchId:bId
      });
    }

    for (const element of paymentDetails) {
      const { paymentAccount, paymentAmount } = element;

      const account = await accountMaster.findOne({ _id: paymentAccount });
      if (!account) {
        return res.status(400).json({
          error: true,
          message: `Payment account ${paymentAccount} does not exist.`,
        });
      }
      const formattedDate = moment().format("DD/MM/YYYY HH:mm:ss");

      account.balance += Number(paymentAmount);
      await account.save();
      await TransactionHistory.create({
        account: paymentAccount,
        amount: paymentAmount,
        transactionType: "C",
        customerId: buyer._id,
        transactionDate: formattedDate,
        description: `Payment received for devices  `,
      });
      await CustomerBalance.create({
        customerId: buyer._id,
        account: paymentAccount,
        amount: paymentAmount,
        transactionType: "D",
        transactionDate: formattedDate,
        description: `Payment sent for device.`,
      });
    }

    let sellDeviceList = [];

    for (const sellRequest of sellRequests) {
      const { deviceId, sellingPrice, attachments } = sellRequest;

      const device = await Device.findById(deviceId);
      if (!device || device.isSold === "1") {
        return res.status(400).json({
          error: true,
          message: `Device not found or has been sold.`,
        });
      }

      const sellData = {
        orgId,
        bId,
        userId,
        deviceId,
        deviceData: device,
        sellingPrice,
        pbId: buyer._id,
        customerPhone: buyer.phone,
        customerName: buyer.name,
        attachments: attachments,
        paymentDetails : paymentDetails
      };

      sellDeviceList.push(sellData);
      await Device.findByIdAndUpdate(
        deviceId,
        {
          isSold: "1",
        },
        { new: true }
      );
    }

    const sellDevices = await sellDevice.insertMany(sellDeviceList);
    return res.status(200).json({
      error: false,
      message: "Devices sold successfully",
      data: sellDevices,
    });
  } catch (error) {
    return res.status(400).json({ error: true, message: error.message });
  }
};
