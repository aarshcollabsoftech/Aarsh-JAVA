const { default: mongoose } = require("mongoose");
const user = require("../models/user");
const deviceNameMaster = require("../models/deviceNameMaster");

exports.createdeviceName = async (req, res) => {
  try {
    const { categoryId,modelId,deviceName } = req.body;
    const { userId } = req;

    const added = await deviceNameMaster.create({ userId, categoryId,modelId, deviceName });

    return res.status(200).json({
      error: false,
      message: "deviceName added successfully",
      data: added,
    });
  } catch (error) {
    return res.status(400).json({ error: true, message: error.message });
  }
};

exports.updatedeviceName= async (req, res) => {
  try {
    const { id } = req.params;
    const { deviceName } = req.body;

    const updated = await deviceNameMaster.findByIdAndUpdate(
      id,
      { deviceName },
      { new: true }
    );

    return res.status(200).json({
      error: false,
      message: "deviceName updated successfully",
      data: updated,
    });
  } catch (error) {
    return res.status(400).json({ error: true, message: error.message });
  }
};

exports.deletedeviceName = async (req, res) => {
  try {
    const { id } = req.params;

    const deleted = await deviceNameMaster.findByIdAndUpdate(
      id,
      { isDelete: "1" },
      { new: true }
    );

    return res.status(200).json({
      error: false,
      data: deleted,
      message: "deviceName deleted successfully",
    });
  } catch (error) {
    return res.status(400).json({ error: true, message: error.message });
  }
};

exports.getAlldeviceName = async (req, res) => {
  try {
    const { userId } = req;
    const userData = await user.findById(userId);

    let finalObject = {};
    if (userData?.role == "E" && userData !== null) {
      finalObject = {
        isDelete: "0",
        userId: new mongoose.Types.ObjectId(userData.orgId),
      };
    } else if (userData?.role == "A" && userData !== null) {
      finalObject = {
        isDelete: "0",
      };
    } else {
      finalObject = {
        isDelete: "0",
        userId,
      };
    }
    const deviceNames = await deviceNameMaster
      .find(finalObject)
      .sort({ createdAt: -1 })
      .lean()
      .exec();

    return res.status(200).json({
      error: false,
      message: "deviceName fetched successfully",
      data: deviceNames,
      userId,
    });
  } catch (error) {
    return res.status(400).json({ error: true, message: error.message });
  }
};
exports.getAlldeviceNameForDisplay = async (req, res) => {
  try {
   
    const deviceNames = await deviceNameMaster
      .find({isDelete:"0"})
      .sort({ createdAt: -1 })
      .lean()
      .exec();

    return res.status(200).json({
      error: false,
      message: "deviceName fetched successfully",
      data: deviceNames,
    });
  } catch (error) {
    return res.status(400).json({ error: true, message: error.message });
  }
};
