const { default: mongoose } = require("mongoose");
const categoryMaster = require("../models/categoryMaster");
const user = require("../models/user");

exports.createcategory = async (req, res) => {
  try {
    const { category } = req.body;
    const { userId } = req;

    const added = await categoryMaster.create({ userId, category });

    return res.status(200).json({
      error: false,
      message: "category added successfully",
      data: added,
    });
  } catch (error) {
    return res.status(400).json({ error: true, message: error.message });
  }
};

exports.updatecategory = async (req, res) => {
  try {
    const { id } = req.params;
    const { category } = req.body;

    const updated = await categoryMaster.findByIdAndUpdate(
      id,
      { category },
      { new: true }
    );

    return res.status(200).json({
      error: false,
      message: "category updated successfully",
      data: updated,
    });
  } catch (error) {
    return res.status(400).json({ error: true, message: error.message });
  }
};

exports.deletecategory = async (req, res) => {
  try {
    const { id } = req.params;

    const deleted = await categoryMaster.findByIdAndUpdate(
      id,
      { isDelete: "1" },
      { new: true }
    );

    return res.status(200).json({
      error: false,
      data: deleted,
      message: "category deleted successfully",
    });
  } catch (error) {
    return res.status(400).json({ error: true, message: error.message });
  }
};

exports.getAllcategory = async (req, res) => {
  try {
    const { userId } = req;
    const userData = await user.findById(userId);

    let finalObject = {};
    if (userData?.role == "E" && userData !== null) {
      finalObject = {
        isDelete: "0",
        userId: new mongoose.Types.ObjectId(userData.orgId),
      };
    } else if (userData?.role == "A" && userData !== null) {
      finalObject = {
        isDelete: "0",
      };
    } else {
      finalObject = {
        isDelete: "0",
        userId,
      };
    }
    const categories = await categoryMaster
      .find(finalObject)
      .sort({ createdAt: -1 })
      .lean()
      .exec();

    return res.status(200).json({
      error: false,
      message: "category fetched successfully",
      data: categories,
      userId,
    });
  } catch (error) {
    return res.status(400).json({ error: true, message: error.message });
  }
};
exports.getAllcategoryForDisplay = async (req, res) => {
  try {
    
    const categories = await categoryMaster
      .find({isDelete:"0"})
      .sort({ createdAt: -1 })
      .lean()
      .exec();

    return res.status(200).json({
      error: false,
      message: "category fetched successfully",
      data: categories,
    });
  } catch (error) {
    return res.status(400).json({ error: true, message: error.message });
  }
};
