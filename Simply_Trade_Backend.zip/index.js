const express = require("express");
const cors = require("cors");
const app = express();
const { routes } = require("./common/common");
app.use(express.json({ limit: "500mb" }));

const env = require("dotenv");
const connectDB = require("./db/db");
const { apiMiddleware } = require("./middleware/middleware");
env.config();

const PORT = process.env.PORT;
connectDB();

app.use(cors());

app.use(apiMiddleware);
routes.forEach((route) => {
  app.use(route.path, route.router);
});

app.listen(PORT, () => {
  console.log(`Server run on PORT : ${PORT}`);
});
