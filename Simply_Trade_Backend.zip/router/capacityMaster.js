const express = require("express");
const {
  createCapacity,
  updateCapacity,
  deleteCapacity,
  getAllCapacity,
  getAllCapacityForDisplay,
} = require("../controller/capacityMaster");
const { authMiddleware } = require("../middleware/middleware");

const router = express.Router();

router.post("/createcapacity", authMiddleware, createCapacity);

router.put("/updatecapacity/:id", authMiddleware, updateCapacity);
router.put("/deletecapacity/:id", authMiddleware, deleteCapacity);
router.get("/getcapacities", authMiddleware, getAllCapacity);
router.get("/getAllcapacitiesfordisplay", getAllCapacityForDisplay);

module.exports = router;
