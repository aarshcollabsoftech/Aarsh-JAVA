const { default: mongoose } = require("mongoose");
const user = require("../models/user");
const CustomerBalance = require("../models/cutomerBalanceHistory");
exports.getCustomerBalance = async (req, res) => {
  try {
    const { userId } = req;
    const userData = await user.findById(userId);

    let finalObject = {};
    if (userData?.role == "E" && userData !== null) {
      finalObject = {
        userId: new mongoose.Types.ObjectId(userData.orgId),
      };
    } else if (userData?.role == "A" && userData !== null) {
      finalObject = {
      };
    } else {
      finalObject = {
        userId,
      };
    }
    const history = await CustomerBalance
      .find(finalObject)
      .sort({ createdAt: -1 })
      .lean()
      .exec();

    return res.status(200).json({
      error: false,
      message: "Customer Balance  fetched successfully",
      data: history,
      userId,
    });
  } catch (error) {
    return res.status(400).json({ error: true, message: error.message });
  }
};
