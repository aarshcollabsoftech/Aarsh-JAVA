const User = require("../models/user");
const bcrypt = require("bcrypt");
const JWT = require("jsonwebtoken");
const nodemailer = require("nodemailer");
const organization = require("../models/organization");
const orgBranch = require("../models/orgBranch");

/*************** Login *******************/

exports.login = async (req, res) => {
  try {
    const { userName, password } = req.body;

    const user = await User.findOne({
      $or: [{ email: userName }, { phone: userName }],
    });

    const org = await organization.findOne({
      $or: [{ email: userName }, { mobile: userName }],
    });

    const branch = await orgBranch.findOne({
      $or: [{ email: userName }, { mobile: userName }],
    });

    if (!user && !org && !branch) {
      return res
        .status(400)
        .json({ error: true, message: "Incorrect login credentials." });
    }

    if (user) {
      if (user.isVerified == 0) {
        return res.status(400).json({
          error: true,
          message:
            "User Verification Failed.Check your Registered Mail for the verifcation link .",
        });
      }
      if (user.isDelete == "1") {
        return res.status(400).json({
          error: true,
          message: "You can't login please contact your admin.",
        });
      }
      if (user.role == "E" && user.bId.length !== 0) {
        let isBranchNotDeleted = false;

        for (const element of user.bId) {
          const Branch = await orgBranch.findById(element);
          if (Branch.isDelete != "1") {
            isBranchNotDeleted = true;
            break;
          }
        }

        if (!isBranchNotDeleted) {
          return res.status(400).json({
            error: true,
            message: `You can't login please contact branch admin.`,
          });
        }
      }
      const comparePass = await bcrypt.compare(password, user.password);
      if (!comparePass) {
        return res
          .status(400)
          .json({ error: true, message: "Incorrect Login Credentials." });
      }
      JWT_DATA = {
        userId: user.id,
        role: user.role,
      };
    } else if (org) {
      if (org.isDelete == "!") {
        return res.status(400).json({
          error: true,
          message: "You can't login please contact your admin.",
        });
      }
      const comparePass = await bcrypt.compare(password, org.password);
      if (!comparePass) {
        return res
          .status(400)
          .json({ error: true, message: "Incorrect Login Credentials." });
      }
      JWT_DATA = {
        userId: org.id,
        role: "Org",
      };
    } else if (branch) {
      if (branch.isDelete == "!") {
        return res.status(400).json({
          error: true,
          message: "You can't login please contact your Organization.",
        });
      }
      const findOrg = await organization.findById(branch.organizationId);
      if (findOrg.isDelete == "1") {
        return res.status(400).json({
          error: true,
          message: "You can't login please contact your Organization.",
        });
      }
      const comparePass = await bcrypt.compare(password, branch.password);
      if (!comparePass) {
        return res
          .status(400)
          .json({ error: true, message: "Incorrect login credentials." });
      }
      JWT_DATA = {
        userId: branch.id,
        role: "OrgBranch",
      };
    }

    const token = JWT.sign(JWT_DATA, process.env.JWT_SECRET_KEY, {
      expiresIn: "24h",
    });

    const userId = user ? user._id : org ? org._id : branch ? branch._id : null;
    const name = user
      ? user.name
      : org
      ? org.orgName
      : branch
      ? branch.branchName
      : null;
    const email = user
      ? user.email
      : org
      ? org.email
      : branch
      ? branch.email
      : null;
    const phone = user
      ? user.phone
      : org
      ? org.mobile
      : branch
      ? branch.mobile
      : null;
    const role = user ? user.role : org ? "Org" : branch ? "OrgBranch" : null;

    return res.status(200).json({
      error: false,
      message: "User login successful.",
      token,
      data: {
        userId: userId,
        name: name,
        email: email,
        phone: phone,
        role: role,
      },
    });
  } catch (error) {
    return res.status(400).json({ error: true, message: error.message });
  }
};

/*************** Add User *******************/

exports.addUser = async (req, res) => {
  try {
    let { name, email, phone, password, orgId, bId } = req.body;
    const { userId } = req;

    email = email.toLowerCase();

    const userMail = await User.findOne({ email, isDelete: 0 });
    const userphone = await User.findOne({ phone, isDelete: 0 });

    if (userMail) {
      return res.status(400).json({
        error: true,
        message: "User already exists with this Email.",
      });
    }
    if (userphone) {
      return res.status(400).json({
        error: true,
        message: "User already exists with this Phone Number.",
      });
    }

    const salt = await bcrypt.genSalt(10);
    const bcryptPass = await bcrypt.hash(password, salt);

    const user = await User.create({
      userId,
      name,
      email,
      role: "E",
      phone,
      password: bcryptPass,
      bId,
      orgId,
    });

    JWT_DATA = {
      userId: user._id,
      role: user.role,
    };

    const token = JWT.sign(JWT_DATA, process.env.JWT_SECRET_KEY);

    const oldToken = token.split(".");
    const urlToken = `${oldToken[0]}/${oldToken[1]}/${oldToken[2]}`;
    const Url = `${process.env.VITE_FRONTEND_PATH}/verifyuser/${urlToken}`;
    let transporter = nodemailer.createTransport({
      service: "Gmail",
      auth: {
        user: "tarunrudakiya123@gmail.com",
        pass: "zbqq zncs dusx ocsc",
      },
    });

    let info = await transporter.sendMail({
      from: "tarunrudakiya123@gmail.com",
      to: email,
      subject: "Email Verification",
      text: `Please verify your email. ${Url}`,
    });

    const data = {
      name: user.name,
      email: user.email,
      phone: user.phone,
      role: user.role,
      bId: user.bId,
      _id: user._id,
    };

    return res.status(200).json({
      error: false,
      message: "User created Successfully.",
      data: data,
    });
  } catch (error) {
    return res.status(400).json({ error: true, message: error.message });
  }
};

/*************** Update User By Token *******************/

exports.verifyUserbytoken = async (req, res) => {
  const { token } = req.params;

  try {
    var decoded = JWT.verify(token, process.env.JWT_SECRET_KEY);

    const { userId } = decoded;

    const ValidUser = await User.findByIdAndUpdate(
      userId,
      { isVerified: 1 },
      { new: true }
    );

    res.status(200).json({
      error: false,
      data: ValidUser,
      message: "Verification Successful",
    });
  } catch (error) {
    return res.status(400).json({ error: true, message: error.message });
  }
};

/*************** Forgot Password *******************/

exports.forgotPassword = async (req, res) => {
  const { email } = req.body;
  const user = await User.findOne({ email }).select("-password");

  if (!user) {
    return res.status(400).json({
      error: true,
      message: `Incorrect credentials.`,
      success: false,
    });
  }

  JWT_DATA = {
    userId: user._id,
  };

  const token = JWT.sign(JWT_DATA, process.env.JWT_SECRET_KEY, {
    expiresIn: "30d",
  });

  const urlToken = token.split(".");
  const link = `${process.env.VITE_FRONTEND_PATH}/resetpassword/${urlToken[0]}/${urlToken[1]}/${urlToken[2]}`;
  const transporter = nodemailer.createTransport({
    service: "Gmail",
    auth: {
      user: "tarunrudakiya123@gmail.com",
      pass: "zbqq zncs dusx ocsc",
    },
  });

  const mailOptions = {
    from: "tarunrudakiya123@gmail.com",
    to: email,
    subject: "Reset Password",
    text: `This mail from Simply Trade is regarding password change request.Follow the given link to set new password. 
    Link : ${link}`,
  };

  try {
    transporter.sendMail(mailOptions, function (err, data) {
      if (err) {
        return res.status(400).json({ err, success: false });
      } else {
        return res.status(200).json({
          error: false,
          message: `Link sent to your registered Email-Id.`,
          success: true,
        });
      }
    });
  } catch (error) {
    return res.status(400).json({ error: true, message: error.message });
  }
};

/*************** Reset Password *******************/

exports.resetPassword = async (req, res) => {
  try {
    const { t1, t2, t3, password } = req.body;
    let token = t1 + "." + t2 + "." + t3;

    var decoded = JWT.verify(token, process.env.JWT_SECRET_KEY);

    const { userId } = decoded;
    const salt = await bcrypt.genSalt(10);
    const bcryptPass = await bcrypt.hash(password, salt);

    await User.findByIdAndUpdate(
      userId,
      { password: bcryptPass },
      { new: true }
    );

    return res
      .status(200)
      .json({ error: false, message: "Password reset successfully." });
  } catch (error) {
    return res.status(400).json({ error: true, message: error.message });
  }
};

/*************** Sign Up *******************/

exports.signup = async (req, res) => {
  try {
    let { name, email, phone, password, amount, bId } = req.body;

    email = email.toLowerCase();

    const userMail = await User.findOne({ email });
    const userphone = await User.findOne({ phone });

    if (userMail) {
      return res.status(400).json({
        error: true,
        message: "User already exists with this Email.",
      });
    }
    if (userphone) {
      return res.status(400).json({
        error: true,
        message: "User already exists with this Phone Number.",
      });
    }

    const salt = await bcrypt.genSalt(10);
    const bcryptPass = await bcrypt.hash(password, salt);

    const user = await User.create({
      name,
      email,
      role: "A",
      phone,
      amount,
      password: bcryptPass,
      bId,
      isVerified: "1",
    });

    const data = {
      name: user.name,
      email: user.email,
      phone: user.phone,
      role: user.role,
      bId: user.bId,
      _id: user._id,
    };

    return res.status(200).json({
      error: false,
      message: "User created Successfully.",
      data: data,
    });
  } catch (error) {
    return res.status(400).json({ error: true, message: error.message });
  }
};

exports.editUser = async (req, res) => {
  try {
    const { id } = req.params;
    const { userId } = req;

    const updated = await User.findByIdAndUpdate(id, req.body, {
      new: true,
    });

    return res.status(200).json({
      error: false,
      message: "User updated successfully",
      userId: userId,
      data: updated,
    });
  } catch (error) {
    return res.status(400).json({ error: true, message: error.message });
  }
};

exports.deleteUser = async (req, res) => {
  try {
    const { id } = req.params;

    const deleted = await User.findByIdAndUpdate(
      id,
      { isDelete: 1 },
      {
        new: true,
      }
    );

    return res.status(200).json({
      error: false,
      message: "User deleted successfully",
      data: deleted,
    });
  } catch (error) {
    return res.status(400).json({ error: true, message: error.message });
  }
};
