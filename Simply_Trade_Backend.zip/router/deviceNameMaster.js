const express = require("express");

const { authMiddleware } = require("../middleware/middleware");
const { createdeviceName, updatedeviceName, deletedeviceName, getAlldeviceName, getAlldeviceNameForDisplay } = require("../controller/deviceNameMaster");

const router = express.Router();

router.post("/createdeviceName", authMiddleware, createdeviceName);

router.put("/updatedeviceName/:id", authMiddleware, updatedeviceName);
router.put("/deletedeviceName/:id", authMiddleware, deletedeviceName);
router.get("/getAlldeviceName", authMiddleware, getAlldeviceName);
router.get("/getalldevicenamefordisplay",getAlldeviceNameForDisplay);

module.exports = router;
