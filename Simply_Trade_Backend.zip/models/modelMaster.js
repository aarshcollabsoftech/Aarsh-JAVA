const mongoose = require("mongoose");

const modelMasterSchema = mongoose.Schema(
  {
    categoryId: {
      type: String,
      trim: true,
    },
    modelName: {
      type: String,
      trim: true,
    },
    isDelete: {
      type: String,
      enum: [1, 0],
      default: 0,
      trim: true,
    },
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "user",
    },
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model("modelmaster", modelMasterSchema);
