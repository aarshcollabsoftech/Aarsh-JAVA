const express = require("express");
const {
  getBranchUsers,
  updateUserById,
  deleteUserById,
  getUserByToken,
  getUsers,
} = require("../controller/user");
const { authMiddleware } = require("../middleware/middleware");

const router = express.Router();

router.get("/getbranchusers/:bId", authMiddleware, getBranchUsers);
router.put("/updateuserbyid/:id", authMiddleware, updateUserById);
router.put("/deleteuserbyid/:id", authMiddleware, deleteUserById);
router.post("/getuserbytoken", authMiddleware, getUserByToken);
router.get("/getusers", authMiddleware, getUsers);

module.exports = router;
