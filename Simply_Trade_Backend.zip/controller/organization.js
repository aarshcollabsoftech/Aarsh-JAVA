const Org = require("../models/organization");
const bcrypt = require("bcrypt");

/*************** Create Organization  ***************/

exports.createorg = async (req, res) => {
  try {
    const { userId } = req;
    const {
      adminId,
      GSTIN,
      orgName,
      primaryAddress,
      addresslineOne,
      addresslineTwo,
      city,
      pinCode,
      district,
      state,
      country,
      mobile,
      telephone,
      email,
      companyRegType,
      dealingCurrency,
      financialYear,
      defaultStockCalcMethod,
      uploadDocs,
      password,
    } = req.body;

    const findEmail = await Org.find({ email });
    const findMobile = await Org.find({ mobile });
    if (findEmail && findEmail.length > 0) {
      return res
        .status(400)
        .json({ error: false, message: "Email already exists" });
    }
    if (findMobile && findMobile.length > 0) {
      return res
        .status(400)
        .json({ error: false, message: "Phone already exists" });
    }

    const salt = await bcrypt.genSalt(10);
    const bcryptPass = await bcrypt.hash(password, salt);

    const org = await Org.create({
      adminId: userId,
      GSTIN,
      orgName,
      primaryAddress,
      addresslineOne,
      addresslineTwo,
      city,
      pinCode,
      district,
      state,
      country,
      mobile,
      telephone,
      email,
      companyRegType,
      dealingCurrency,
      financialYear,
      defaultStockCalcMethod,
      uploadDocs,
      password: bcryptPass,
    });

    return res.status(200).json({
      error: false,
      data: org,
      message: "Organization created successfully",
    });
  } catch (error) {
    return res.status(400).json({ error, message: "Something went wrong" });
  }
};

/*************** Get  Organization  By Admin Id ***************/

exports.getorgbyadminid = async (req, res) => {
  try {
    const { aId } = req.params;
    const { userId } = req;

    const gorgbyadmin = await Org.find({ adminId: userId, isDelete: "0" })
      .select("-password")
      .sort({ createdAt: -1 })
      .lean()
      .exec();

    return res.status(200).json({ error: false, data: gorgbyadmin, userId });
  } catch (error) {
    return res.status(400).json({ error: true, message: error.message });
  }
};

/*************** Get  Organization  ***************/

exports.getorg = async (req, res) => {
  try {
    const { userId } = req;

    const gorg = await Org.find({ isDelete: "0", adminId: userId })
      .select("-password")
      .sort({ createdAt: -1 })
      .lean()
      .exec();
    return res.status(200).json({ error: false, data: gorg, userId });
  } catch (error) {
    return res.status(400).json({ error: true, message: error.message.error });
  }
};

/*************** Get  Organization  By  Id ***************/

exports.getorgbyid = async (req, res) => {
  try {
    const { userId } = req;

    const gidorg = await Org.findById(userId)
      .select("-password")
      .sort({ createdAt: -1 })
      .lean()
      .exec();
    return res.status(200).json({ error: false, data: gidorg });
  } catch (error) {
    return res.status(400).json({ error: true, message: error.message });
  }
};

/*************** Update Organization  By  Id ***************/

exports.updateorgbyid = async (req, res) => {
  try {
    const { id } = req.params;
    let bcryptPass;
    if (req.body.password) {
      const salt = await bcrypt.genSalt(10);
      bcryptPass = await bcrypt.hash(req.body.password, salt);
    }
    let finalObject = {
      ...req.body,
      password: bcryptPass,
    };
    const uidorg = await Org.findByIdAndUpdate(id, finalObject, { new: true });
    return res.status(200).json({
      error: false,
      data: uidorg,
      message: "Organization Updated Successfully",
    });
  } catch (error) {
    return res.status(400).json({ error, message: "Something went wrong" });
  }
};

/*************** Delete Organization By Id ***************/
exports.deleteorgbyid = async (req, res) => {
  try {
    const { id } = req.params;
    const dorg = await Org.findByIdAndUpdate(
      id,
      { isDelete: 1 },
      { new: true }
    );
    return res.status(200).json({
      error: false,
      data: dorg,
      message: "Organization Deleted Successfully",
    });
  } catch (error) {
    return res.status(400).json({ error: true, message: "Internal Error" });
  }
};

/*************** Block  Organization By Id   ***************/

exports.blockorgbyid = async (req, res) => {
  try {
    const { id } = req.params;
    const borg = await Org.findByIdAndUpdate(id, { isBlock: 1 }, { new: true });
    return res.status(200).json({ error: false, data: borg });
  } catch (error) {
    return res.status(400).json({ error: true, message: error.message });
  }
};
